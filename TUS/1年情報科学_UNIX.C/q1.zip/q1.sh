#! /bin/bash
alias $1='ls -l | grep .txt | head -3'
