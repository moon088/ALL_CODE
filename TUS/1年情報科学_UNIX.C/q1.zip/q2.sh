#! /bin/bash
PS1="\w\$"
