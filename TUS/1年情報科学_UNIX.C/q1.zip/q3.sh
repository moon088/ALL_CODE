#! bin/bash
ls -l | grep $1 
