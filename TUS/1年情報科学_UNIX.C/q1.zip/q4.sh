#! bin/bash

if [ -d ./$1 ]
then
echo $1 is directory
elif [ -f ./$1 ]
then
echo $1 is file
else
echo $1 is not found
fi
