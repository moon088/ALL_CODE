#! bin/bash 
mkdir ~/main ~/main/sub1 ~/main/sub2 ~/main/sub1/sub1sub1 ~/main/sub1/sub1sub2 ~/main/sub2/sub2sub1 
echo reportkadai > ~/main/sub2/text.txt
