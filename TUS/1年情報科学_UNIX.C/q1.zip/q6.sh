#! bin/bash
if [ -d ~/main ]
then
echo main---true
else
echo main---false
fi

if [ -d ~/main/sub1 ]
then
echo sub1---true
else
echo sub1---false
fi

if [ -d ~/main/sub1/sub1sub1 ]
then
echo sub1sub1---true
else
echo sub1sub1---false
fi

if [ -d ~/main/sub1/sub1sub2 ]
then 
echo sub1sub2---true
else
echo sub1sub2---false
fi

if [ -d ~/main/sub2 ]
then 
echo sub2---true
else
echo sube---false
fi

if [ -d ~/main/sub2/sub2sub1 ]
then
echo sub2sub1---true
else
echo sub2sub1---false
fi

if [ -f ~/main/sub2/text.txt ]
then
echo text.txt---true
else
echo text.txt---false
fi
